import React, { createContext, useContext, useState } from 'react';

const CarrinhoContext = createContext(null);

const TAXA_ENTREGA = 6.0;

export function CarrinhoProvider({ children }) {
  const [itens, setItens] = useState([]);

  function adicionarAoCarrinho(produto) {
    setItens((atual) => {
      const existente = atual.find((item) => item.id === produto.id);
      if (existente) {
        return atual.map((item) =>
          item.id === produto.id
            ? { ...item, quantidade: item.quantidade + 1 }
            : item
        );
      }
      return [...atual, { ...produto, quantidade: 1 }];
    });
  }

  function incrementarQuantidade(id) {
    setItens((atual) =>
      atual.map((item) =>
        item.id === id ? { ...item, quantidade: item.quantidade + 1 } : item
      )
    );
  }

  function decrementarQuantidade(id) {
    setItens((atual) =>
      atual
        .map((item) =>
          item.id === id ? { ...item, quantidade: item.quantidade - 1 } : item
        )
        .filter((item) => item.quantidade > 0) // RF07: remove ao chegar em 0
    );
  }

  const totalItens = itens.reduce((soma, item) => soma + item.quantidade, 0);
  const subtotal = itens.reduce((soma, item) => soma + item.preco * item.quantidade, 0);
  const taxaEntrega = itens.length > 0 ? TAXA_ENTREGA : 0;
  const total = subtotal + taxaEntrega;

  return (
    <CarrinhoContext.Provider
      value={{
        itens,
        totalItens,
        subtotal,
        taxaEntrega,
        total,
        adicionarAoCarrinho,
        incrementarQuantidade,
        decrementarQuantidade,
      }}
    >
      {children}
    </CarrinhoContext.Provider>
  );
}

export function useCarrinho() {
  return useContext(CarrinhoContext);
}