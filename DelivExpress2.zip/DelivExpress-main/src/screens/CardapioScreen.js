import React from 'react';
import {
  View, Text, Image, ScrollView, TouchableOpacity, StyleSheet,
} from 'react-native';
import { produtos } from '../data/produtos';
import { cores } from '../constants/cores';
import { useCarrinho } from '../context/CarrinhoContext';

export default function CardapioScreen({ navigation }) {
  const { totalItens, adicionarAoCarrinho } = useCarrinho();

  function formatarPreco(valor) {
    return `R$ ${valor.toFixed(2).replace('.', ',')}`;
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.tituloHeader}>DelivExpress</Text>
        <TouchableOpacity
          style={styles.badge}
          onPress={() => navigation.navigate('Carrinho')}
        >
          <Text style={styles.badgeTexto}>{totalItens}</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.lista}>
        {produtos.map((produto) => (
          <View key={produto.id} style={styles.card}>
            <Image source={{ uri: produto.imagem }} style={styles.imagem} width={64} height={64} />
            <View style={styles.infoProduto}>
              <Text style={styles.nomeProduto}>{produto.nome}</Text>
              <Text style={styles.descricaoProduto}>{produto.descricao}</Text>
              <Text style={styles.precoProduto}>{formatarPreco(produto.preco)}</Text>
            </View>
            <TouchableOpacity
              style={styles.botaoAdicionar}
              onPress={() => adicionarAoCarrinho(produto)}
              activeOpacity={0.7}
            >
              <Text style={styles.textoBotao}>+ Add</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

// styles: mantenha exatamente os mesmos que você já tem
const styles = StyleSheet.create({ /* ...cole os estilos que já existem... */ });